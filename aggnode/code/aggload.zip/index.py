import boto3
import pandas as pd
import psycopg2
import psycopg2.extras as extras
import time
from datetime import date
import re


# import json

dataPath = "s3://s3-for-athena-bintest2/data/"

def lambda_handler(event, context):
    #try:
    if 1:
        bucket = event['Records'][0]['s3']['bucket']['name']
        key = event['Records'][0]['s3']['object']['key']
        loadFile(bucket, key)
    if 1:
        requestid = extractMetadata(bucket, key, dataPath)
        mvFile(bucket, key, dataPath, requestid)
        createAthenaTable(dataPath, requestid)
    return key +" loaded to DB and Athena for " + requestid

def loadFile(bucket, key):
    #obj = s3.Object(bucket_name= bucket, key= key)
    #response = obj.get()
    print("Loading " + key)
    s3 = boto3.client('s3')
    response = s3.get_object(Bucket= bucket, Key= key)
    df = pd.read_csv(response.get("Body"),dtype=str)
    for index, row in df.iterrows():
        try:
            site = row["site"]
            requestid = row["requestid"]
        except:
            print("ERROR: check site and requestid")
            return
        break
    conn = psycopg2.connect(
        host= $SERVER_IP,
        database="postgres",
        user= $USER,
        password= $PASS)

    cur = conn.cursor()
    
    # create table if not exists
    tableSchema = ""
    for col in df.columns:
        if col == 'cnt':
            tableSchema += col + " int,"
        else:
           tableSchema += col + " varchar," 
    tableSchema = tableSchema + "import_date timestamp, active_status boolean"

    sql_create = "create table if not exists req_" + requestid + " (" + tableSchema + ");"

    # mark old rows as inactive f
    sql_mark = "UPDATE req_" + requestid + " SET active_status = False where " +\
        " requestid = '" + requestid + "' "+\
        " and site = '" + site + "' "

    # add new records
    df["import_date"] =  pd.to_datetime('now', utc=True).strftime('%Y-%m-%d')
    df["active_status"] = True
    tuples = [tuple(x) for x in df.to_numpy()]
    cols = ','.join(list(df.columns))
    query = "INSERT INTO %s(%s) VALUES %%s" % ("req_" +requestid, cols)
    
    try:
        cur.execute(sql_create)
        cur.execute(sql_mark)
        extras.execute_values(cur, query, tuples)
        conn.commit()
        print(key + " loaded")
    except:
        print(key + " failed to load")
        conn.rollback()

    cur.close()   

# extract metadata for athena external table
def backtick(s):
    reserved_words = ["ALL", "ALTER", "AND", "ARRAY", "AS", "AUTHORIZATION", "BETWEEN", "BIGINT", "BINARY", "BOOLEAN", "BOTH", "BY", "CASE", "CASHE", "CAST", "CHAR", "COLUMN", "CONF", "CONSTRAINT", "COMMIT", "CREATE", "CROSS", "CUBE", "CURRENT", "CURRENT_DATE", "CURRENT_TIMESTAMP", "CURSOR", "DATABASE", "DATE", "DAYOFWEEK", "DECIMAL", "DELETE", "DESCRIBE", "DISTINCT", "DOUBLE", "DROP", "ELSE", "END", "EXCHANGE", "EXISTS", "EXTENDED", "EXTERNAL", "EXTRACT", "FALSE", "FETCH", "FLOAT", "FLOOR", "FOLLOWING", "FOR", "FOREIGN", "FROM", "FULL", "FUNCTION", "GRANT", "GROUP", "GROUPING", "HAVING", "IF", "IMPORT", "IN", "INNER", "INSERT", "INT", "INTEGER,INTERSECT", "INTERVAL", "INTO", "IS", "JOIN", "LATERAL", "LEFT", "LESS", "LIKE", "LOCAL", "MACRO", "MAP", "MORE", "NONE", "NOT", "NULL", "NUMERIC", "OF", "ON", "ONLY", "OR", "ORDER", "OUT", "OUTER", "OVER", "PARTIALSCAN", "PARTITION", "PERCENT", "PRECEDING", "PRECISION", "PRESERVE", "PRIMARY", "PROCEDURE", "RANGE", "READS", "REDUCE", "REGEXP,REFERENCES", "REVOKE", "RIGHT", "RLIKE", "ROLLBACK", "ROLLUP", "ROW", "ROWS", "SELECT", "SET", "SMALLINT", "START,TABLE", "TABLESAMPLE", "THEN", "TIME", "TIMESTAMP", "TO", "TRANSFORM", "TRIGGER", "TRUE", "TRUNCATE", "UNBOUNDED,UNION", "UNIQUEJOIN", "UPDATE", "USER", "USING", "UTC_TIMESTAMP", "VALUES", "VARCHAR", "VIEWS", "WHEN", "WHERE", "WINDOW", "WITH"]
    if s.upper() in reserved_words:
        s = "`" + s + "`"
    return s

def extractMetadata(bucket, key, dataPath):
    typeMap = {"object":"string", "int64":"string"}
    s3 = boto3.client('s3')
    response = s3.get_object(Bucket= bucket, Key= key)
    df = pd.read_csv(response.get("Body"),low_memory = False)
    typeDict = {backtick(k):str(v) for k,v in df.dtypes.items()}
    
    for index, row in df.iterrows():
        try:
            site = row["site"]
            requestid = row["requestid"]
        except:
            print("ERROR: check site and requestid")
            return
        break
    #build schema
    schema = ""
    for i in typeDict:
        schema += i + " " + typeMap[typeDict[i]] + ","
    schema = schema[:-1]
    
    
    pathList = dataPath.split("/")
    outBucket = pathList[2]
    prefList = pathList[3:]
    outPrefix = "/".join(prefList)
    outPrefix = re.sub(r'\/$', '', outPrefix)
    
    s3 = boto3.resource("s3")
    s3.Bucket(outBucket).put_object(Key= outPrefix + "/agg_node/schema/"+ requestid.lower() +'.txt', Body=schema)
    print("output schema to " + outPrefix + "/agg_node/schema/"+ requestid.lower() +'.txt')
    #with open(outPath + "/agg_node/schema/" + requestid.lower() +'.txt', 'w+') as f:
    #    f.write(schema)
    return requestid
    
def mvFile(bucket, key, dataPath, requestid = ""):
    
    if requestid == "":
        # get request id
        s3 = boto3.client('s3')
        response = s3.get_object(Bucket= bucket, Key= key)
        df = pd.read_csv(response.get("Body"),low_memory = False)
        for index, row in df.iterrows():
            try:
                site = row["site"]
                requestid = row["requestid"]
            except:
                print("ERROR: check site and requestid")
                return
            break
    
    pathList = dataPath.split("/")
    outBucket = pathList[2]
    prefList = pathList[3:]
    outPrefix = "/".join(prefList)
    outPrefix = re.sub(r'\/$', '', outPrefix)
    
    s3 = boto3.resource('s3')
    destBucket = s3.Bucket(outBucket)
    copy_source = {'Bucket': bucket,'Key': key}
    
    fileName = key.split("/")[-1]
    destBucket.copy(copy_source, outPrefix + "/agg_node/" + requestid + "/" + fileName)
    # s3.Object(bucket, key).delete()
    return (outBucket, outPrefix + "/agg_node/" + requestid + "/" + fileName)
    
def createAthenaTable(dataPath, requestid):
    client = boto3.client('athena')
    dataPath = re.sub(r'\/$', '', dataPath)
    
    #get schema
    pathList = dataPath.split("/")
    outBucket = pathList[2]
    prefList = pathList[3:]
    outPrefix = "/".join(prefList)
    outPrefix = re.sub(r'\/$', '', outPrefix)
    
    s3 = boto3.resource('s3')
    obj = s3.Object(outBucket, outPrefix + "/agg_node/schema/" + requestid.lower() + ".txt")
    schema = obj.get()['Body'].read().decode('utf-8') 
    
    # get file dir in s3
    s3dir = dataPath + "/agg_node/" + requestid.lower() + "/"
    
    createTb = "CREATE EXTERNAL TABLE IF NOT EXISTS {0} ({1}) \
        ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde' \
        LOCATION '{2}' \
        TBLPROPERTIES ('skip.header.line.count'='1')".format(requestid, schema, s3dir)
    print(createTb)
    response = client.start_query_execution(
        QueryString= createTb,
        QueryExecutionContext={'Database': "aggnode"},
        ResultConfiguration={'OutputLocation': 's3://output-bintest2'}
    )

    return response