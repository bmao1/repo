import json

def lambda_handler(event, context):
    resp = {
          "principalId": "CHIPtester",
          "policyDocument": {
            "Version": "2012-10-17",
            "Statement": [
              {
                "Action": "execute-api:Invoke",
                "Effect": "Deny",
                "Resource": "arn:aws:execute-api:us-east-2:*:*"
              }
            ]
          },
          "context": {
            "exampleKey": "exampleValue"
          }
        }
    try:
        auth = event["headers"]["authorization"]
        if auth == "0": # edit basic auth credential here
            resp["policyDocument"]["Statement"][0]["Effect"] = "Allow"
    except:
        return resp
        
    return resp
    
