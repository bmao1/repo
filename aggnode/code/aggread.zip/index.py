
import boto3
import pandas as pd
import psycopg2
import psycopg2.extras as extras
import time
#from flask import jsonify

def lambda_handler(event, context):
    #return(event)
    '''
    try:
        client_id = event["headers"]["client_id"]
        if client_id != "CHIP":
            return "401 Unauthorized"
    except:
        return "403 Forbidden"
    '''
    if event["rawPath"].lower() == "/read_agg/meta":
        if "queryStringParameters" not in event:
            return "Missing parameters"
        parameters = event["queryStringParameters"]
        if "requestid" not in parameters:
            return "Missing requestid"
            
        conn = psycopg2.connect(
            host="3.139.7.109",
            database="postgres",
            user="postgres",
            password="example")
        cur = conn.cursor()
        #cur.execute("Select * from req_" + parameters["requestid"])
        #colnames = [desc[0] for desc in cur.description]
        
        code = "select column_name, udt_name from information_schema.columns where table_name = 'req_{}'".format(parameters["requestid"])
        cur.execute(code)
        colMeta = cur.fetchall()
        
        ret = []
        for i in colMeta:
            colInfo = {
                "name":i[0],
                "label":i[0],
                "dataType":i[1],
                "description":i[0]
            }
            ret.append(colInfo)
            
        cur.close()
    
        return ret
    
    
    elif event["rawPath"].lower() == "/read_agg/cube":
        if "queryStringParameters" not in event:
            return "Missing parameters"
        parameters = event["queryStringParameters"]
        if "requestid" not in parameters:
            return "Missing requestid"
        elif "cols" not in parameters:
            return "Please specify 'cols' parameter: column names separated by comma"
        
        # set query code components
        if "sort" in parameters:
            orderby = "order by " + parameters["sort"]
        else:
            orderby = ""

        colsList = parameters["cols"].split(",")
        
        selectList = colsList[:]
        for i in range(len(selectList)):
            if selectList[i] == "cnt":
                selectList[i] = "sum(cnt) as cnt"
        selectStr = ",".join(selectList)
        
        groupByList = colsList[:]
        groupByList.remove("cnt")
        groupByStr = ",".join(groupByList)

        # use athena as data source
        if "source" in parameters and parameters["source"] == "athena":
            client = boto3.client('athena')
            selectStr = selectStr.replace("sum(cnt) as cnt", "sum(cast(cnt  as integer)) as cnt")
            selectStr = selectStr.replace("site", "a.site")
            cubeAthenaQuery = "Select {0} FROM {1} a \
                        join \
                        (select site as tempsite\
                            , max(create_date) as tempcreate_date \
                            from {1} \
                            group by site \
                        ) b \
                        on a.site = b.tempsite and a.create_date = b.tempcreate_date group by cube({2}) {3}"\
                .format(selectStr, parameters["requestid"], groupByStr, orderby)
            print(cubeAthenaQuery)
            response = client.start_query_execution(
                QueryString= cubeAthenaQuery,
                QueryExecutionContext={'Database': "aggnode"},
                ResultConfiguration={'OutputLocation': 's3://output-bintest2'}
            )
            query_execution_id = response['QueryExecutionId']
            RETRY_COUNT = 50
            # get execution status
            for i in range(1, 1 + RETRY_COUNT):
    
                # get query execution
                query_status = client.get_query_execution(QueryExecutionId=query_execution_id)
                query_execution_status = query_status['QueryExecution']['Status']['State']
    
                if query_execution_status == 'SUCCEEDED':
                    print("STATUS:" + query_execution_status)
                    break
    
                if query_execution_status == 'FAILED':
                    raise Exception("STATUS:" + query_execution_status)
    
                else:
                    print("STATUS:" + query_execution_status)
                    time.sleep(1)
            else:
                client.stop_query_execution(QueryExecutionId=query_execution_id)
                raise Exception('TIME OVER')
    
            # get query results
            result = client.get_query_results(QueryExecutionId=query_execution_id)
            # return result
            
            # get formated query result
            s3 = boto3.client('s3')
            response = s3.get_object(Bucket= "output-bintest2", Key= "{}.csv".format(query_execution_id))
            df = pd.read_csv(response.get("Body"),low_memory = False)
            df.fillna("",inplace=True)
            rows = df.to_dict('list')
            
            # get column types
            athenaTypeMap = {"object": "string", "float64":"float", "int64":"int"}
            typeDict = {k:str(v) for k,v in df.dtypes.items()}
            
            cols = []
            for t in typeDict:
                if typeDict[t] not in athenaTypeMap:
                    return "Undefined Type " + typeDict[t]
                colInfo = {
                    "name":t,
                    "label":t,
                    "dataType":athenaTypeMap[typeDict[t]],
                    "description":t
                    }
                cols.append(colInfo)
            
            return {
                    "src": parameters["requestid"],
                    "cols": cols,
                    "rows": rows
                }
        # DB connection
        conn = psycopg2.connect(
            host= $SERVER_IP,
            database="postgres",
            user= $USER,
            password= $PASS)
        cur = conn.cursor()
        
        # sort parameter
        
            


        cubeQuery = "Select {0} FROM req_{1} where active_status = True group by cube({2}) {3}"\
            .format(selectStr, parameters["requestid"], groupByStr, orderby)

        cur.execute(cubeQuery)
        rows = cur.fetchall()
        
        # col meta
        colNames = parameters["cols"] + ",cnt"
        requestedList = colNames.split(",")
        
        code = "select column_name, udt_name from information_schema.columns where table_name = 'req_{}'".format(parameters["requestid"])
        cur.execute(code)
        colMeta = cur.fetchall()
        
        colMetaPool = {}
        for i in colMeta:
            colInfo = {
                "name":i[0],
                "label":i[0],
                "dataType":i[1],
                "description":i[0]
            }
            colMetaPool[i[0]] = colInfo
        
        # append column type by the order
        cols = []
        for i in colsList:
            cols.append(colMetaPool[i])
            
            
        ret = {
            "src": parameters["requestid"],
            "cols": cols,
            "rows": rows
        }
        
        cur.close()
        # df = pd.DataFrame(newTuples, columns=colnames.split(","))
        return ret